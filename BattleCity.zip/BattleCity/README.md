# Demo:
(Old)

![Demo1](https://github.com/rintaro129/OOPro/blob/main/BattleCity/res/ezgif-2-016a4d7b49.gif)

![Demo2](https://github.com/rintaro129/OOPro/blob/main/BattleCity/res/ezgif-2-ef20021858.gif)

### Full letsplay of the game you can find [here](https://drive.google.com/file/d/1Ix2TsOcBYyT8102m9gF1zy4He6W2javE/view?usp=sharing)

# Install

Move to the directory, where you want to install, and then clone the repository.
Move to the BattleCity directory.
Build the project and execute the binary as shown below.

```
git clone https://github.com/rintaro129/OOPro.git
cd BattleCity
dotnet build BattleCity.csproj
./bin/Debug/net8.0/BattleCity
```

### Importatnt! Do not move the binary file, the same goes for res directory!

All paths are relative to the location of the binary. Moving these files could lead to improper functioning.


