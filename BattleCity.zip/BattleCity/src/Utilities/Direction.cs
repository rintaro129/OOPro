namespace BattleCity;

public enum Direction
{
    Up,
    Down,
    Left,
    Right,
    None
}